
		************************************************
		************************************************
		*****                                      *****
		*****     Wiimmfi and DWC patcher v4       *****
		*****                                      *****
		************************************************
		*****                                      *****
		*****        For Linux and Windows         *****
		*****              by Wiimm                *****
		*****                                      *****
		************************************************
		************************************************



#######################
     Instructions:
#######################

1.) Copy all original images into the directory of your operating system.

2.) Enter the directory of your operating system.

3.) Linux: Execute: chmod a+x *.sh

4.) Start batch file 'patch-wiimmfi.bat' or 'patch-wiimmfi.sh'.

5.) All new patched images resist in the new sub-directory 'wiimmfi-images/'
    relative to the main directory. Existing files will not overwritten.


Note: Mac is not longer supported by WIT.



####################
     Anleitung:
####################

1.) Kopiere alle Original-Image, die angepasst werden sollen,
    in das Verzeichnis deines betriebssystemes.

2.) Wechsle in das Verzeichnis deines Betriebssystemes.

3.) Nur Linux-Nutzer f�hren das Kommando aus: chmod a+x *.sh

4.) Rufe 'patch-wiimmfi.bat' bzw. 'patch-wiimmfi.sh' auf.

5.) Alle neuen und gepatchten Images befinden sich im Unterverzeichnis
    'wiimmfi-images/' relativ zum Hauptverzeicznis. Dabei werden keine Dateien
    �berschrieben und bereits bestehende Images werden nicht neu erstellt.


Anmerkung: Mac wird nicht mehr unterst�tzt.

